# Web API with ASP.NET Core
Source code for YouTube tutorial on how to create a Web API with ASP.NET Core.
The API exposes endpoints for creating, reading, updating or deleting books.
