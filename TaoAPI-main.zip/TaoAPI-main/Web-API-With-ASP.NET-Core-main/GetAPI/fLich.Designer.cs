﻿
namespace GetAPI
{
    partial class fLich
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtjobcn = new System.Windows.Forms.RichTextBox();
            this.txttimecn = new System.Windows.Forms.RichTextBox();
            this.txtdaycn = new System.Windows.Forms.RichTextBox();
            this.txtjob7 = new System.Windows.Forms.RichTextBox();
            this.txttime7 = new System.Windows.Forms.RichTextBox();
            this.txtday7 = new System.Windows.Forms.RichTextBox();
            this.txtjob6 = new System.Windows.Forms.RichTextBox();
            this.txttime6 = new System.Windows.Forms.RichTextBox();
            this.txtday6 = new System.Windows.Forms.RichTextBox();
            this.txtjob5 = new System.Windows.Forms.RichTextBox();
            this.txttime5 = new System.Windows.Forms.RichTextBox();
            this.txtday5 = new System.Windows.Forms.RichTextBox();
            this.txtjob4 = new System.Windows.Forms.RichTextBox();
            this.txttime4 = new System.Windows.Forms.RichTextBox();
            this.txtday4 = new System.Windows.Forms.RichTextBox();
            this.txtjob3 = new System.Windows.Forms.RichTextBox();
            this.txttime3 = new System.Windows.Forms.RichTextBox();
            this.txtday3 = new System.Windows.Forms.RichTextBox();
            this.txtjob2 = new System.Windows.Forms.RichTextBox();
            this.txttime2 = new System.Windows.Forms.RichTextBox();
            this.txtday2 = new System.Windows.Forms.RichTextBox();
            this.dtgv7 = new System.Windows.Forms.DataGridView();
            this.dtgv6 = new System.Windows.Forms.DataGridView();
            this.dtgv5 = new System.Windows.Forms.DataGridView();
            this.dtgv4 = new System.Windows.Forms.DataGridView();
            this.dtgv3 = new System.Windows.Forms.DataGridView();
            this.dtgv2 = new System.Windows.Forms.DataGridView();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtgvcn = new System.Windows.Forms.DataGridView();
            this.btnsua = new System.Windows.Forms.Button();
            this.btnxoa = new System.Windows.Forms.Button();
            this.btnthem = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.label8 = new System.Windows.Forms.Label();
            this.txtid2 = new System.Windows.Forms.RichTextBox();
            this.txtid3 = new System.Windows.Forms.RichTextBox();
            this.txtid4 = new System.Windows.Forms.RichTextBox();
            this.txtid5 = new System.Windows.Forms.RichTextBox();
            this.txtid6 = new System.Windows.Forms.RichTextBox();
            this.txtid7 = new System.Windows.Forms.RichTextBox();
            this.txtidcn = new System.Windows.Forms.RichTextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvcn)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtidcn);
            this.panel1.Controls.Add(this.txtid7);
            this.panel1.Controls.Add(this.txtid6);
            this.panel1.Controls.Add(this.txtid5);
            this.panel1.Controls.Add(this.txtid4);
            this.panel1.Controls.Add(this.txtid3);
            this.panel1.Controls.Add(this.txtid2);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtjobcn);
            this.panel1.Controls.Add(this.txttimecn);
            this.panel1.Controls.Add(this.txtdaycn);
            this.panel1.Controls.Add(this.txtjob7);
            this.panel1.Controls.Add(this.txttime7);
            this.panel1.Controls.Add(this.txtday7);
            this.panel1.Controls.Add(this.txtjob6);
            this.panel1.Controls.Add(this.txttime6);
            this.panel1.Controls.Add(this.txtday6);
            this.panel1.Controls.Add(this.txtjob5);
            this.panel1.Controls.Add(this.txttime5);
            this.panel1.Controls.Add(this.txtday5);
            this.panel1.Controls.Add(this.txtjob4);
            this.panel1.Controls.Add(this.txttime4);
            this.panel1.Controls.Add(this.txtday4);
            this.panel1.Controls.Add(this.txtjob3);
            this.panel1.Controls.Add(this.txttime3);
            this.panel1.Controls.Add(this.txtday3);
            this.panel1.Controls.Add(this.txtjob2);
            this.panel1.Controls.Add(this.txttime2);
            this.panel1.Controls.Add(this.txtday2);
            this.panel1.Controls.Add(this.dtgv7);
            this.panel1.Controls.Add(this.dtgv6);
            this.panel1.Controls.Add(this.dtgv5);
            this.panel1.Controls.Add(this.dtgv4);
            this.panel1.Controls.Add(this.dtgv3);
            this.panel1.Controls.Add(this.dtgv2);
            this.panel1.Controls.Add(this.dtgvcn);
            this.panel1.Controls.Add(this.btnsua);
            this.panel1.Controls.Add(this.btnxoa);
            this.panel1.Controls.Add(this.btnthem);
            this.panel1.Location = new System.Drawing.Point(15, 71);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1287, 549);
            this.panel1.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(562, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(28, 13);
            this.label3.TabIndex = 56;
            this.label3.Text = "Việc";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(349, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 13);
            this.label2.TabIndex = 55;
            this.label2.Text = "Giờ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(255, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 13);
            this.label1.TabIndex = 54;
            this.label1.Text = "Thứ";
            // 
            // txtjobcn
            // 
            this.txtjobcn.Location = new System.Drawing.Point(553, 470);
            this.txtjobcn.Name = "txtjobcn";
            this.txtjobcn.Size = new System.Drawing.Size(501, 61);
            this.txtjobcn.TabIndex = 53;
            this.txtjobcn.Text = "";
            // 
            // txttimecn
            // 
            this.txttimecn.Location = new System.Drawing.Point(330, 470);
            this.txttimecn.Name = "txttimecn";
            this.txttimecn.Size = new System.Drawing.Size(217, 61);
            this.txttimecn.TabIndex = 52;
            this.txttimecn.Text = "";
            // 
            // txtdaycn
            // 
            this.txtdaycn.Location = new System.Drawing.Point(247, 470);
            this.txtdaycn.Name = "txtdaycn";
            this.txtdaycn.Size = new System.Drawing.Size(77, 61);
            this.txtdaycn.TabIndex = 51;
            this.txtdaycn.Text = "";
            // 
            // txtjob7
            // 
            this.txtjob7.Location = new System.Drawing.Point(553, 394);
            this.txtjob7.Name = "txtjob7";
            this.txtjob7.Size = new System.Drawing.Size(501, 61);
            this.txtjob7.TabIndex = 50;
            this.txtjob7.Text = "";
            // 
            // txttime7
            // 
            this.txttime7.Location = new System.Drawing.Point(330, 394);
            this.txttime7.Name = "txttime7";
            this.txttime7.Size = new System.Drawing.Size(217, 61);
            this.txttime7.TabIndex = 49;
            this.txttime7.Text = "";
            // 
            // txtday7
            // 
            this.txtday7.Location = new System.Drawing.Point(247, 394);
            this.txtday7.Name = "txtday7";
            this.txtday7.Size = new System.Drawing.Size(77, 61);
            this.txtday7.TabIndex = 48;
            this.txtday7.Text = "";
            // 
            // txtjob6
            // 
            this.txtjob6.Location = new System.Drawing.Point(553, 314);
            this.txtjob6.Name = "txtjob6";
            this.txtjob6.Size = new System.Drawing.Size(501, 61);
            this.txtjob6.TabIndex = 47;
            this.txtjob6.Text = "";
            // 
            // txttime6
            // 
            this.txttime6.Location = new System.Drawing.Point(330, 314);
            this.txttime6.Name = "txttime6";
            this.txttime6.Size = new System.Drawing.Size(217, 61);
            this.txttime6.TabIndex = 46;
            this.txttime6.Text = "";
            // 
            // txtday6
            // 
            this.txtday6.Location = new System.Drawing.Point(247, 314);
            this.txtday6.Name = "txtday6";
            this.txtday6.Size = new System.Drawing.Size(77, 61);
            this.txtday6.TabIndex = 45;
            this.txtday6.Text = "";
            // 
            // txtjob5
            // 
            this.txtjob5.Location = new System.Drawing.Point(553, 244);
            this.txtjob5.Name = "txtjob5";
            this.txtjob5.Size = new System.Drawing.Size(501, 61);
            this.txtjob5.TabIndex = 44;
            this.txtjob5.Text = "";
            // 
            // txttime5
            // 
            this.txttime5.Location = new System.Drawing.Point(330, 244);
            this.txttime5.Name = "txttime5";
            this.txttime5.Size = new System.Drawing.Size(217, 61);
            this.txttime5.TabIndex = 43;
            this.txttime5.Text = "";
            // 
            // txtday5
            // 
            this.txtday5.Location = new System.Drawing.Point(247, 244);
            this.txtday5.Name = "txtday5";
            this.txtday5.Size = new System.Drawing.Size(77, 61);
            this.txtday5.TabIndex = 42;
            this.txtday5.Text = "";
            // 
            // txtjob4
            // 
            this.txtjob4.Location = new System.Drawing.Point(553, 176);
            this.txtjob4.Name = "txtjob4";
            this.txtjob4.Size = new System.Drawing.Size(501, 61);
            this.txtjob4.TabIndex = 41;
            this.txtjob4.Text = "";
            // 
            // txttime4
            // 
            this.txttime4.Location = new System.Drawing.Point(330, 176);
            this.txttime4.Name = "txttime4";
            this.txttime4.Size = new System.Drawing.Size(217, 61);
            this.txttime4.TabIndex = 40;
            this.txttime4.Text = "";
            // 
            // txtday4
            // 
            this.txtday4.Location = new System.Drawing.Point(247, 176);
            this.txtday4.Name = "txtday4";
            this.txtday4.Size = new System.Drawing.Size(77, 61);
            this.txtday4.TabIndex = 39;
            this.txtday4.Text = "";
            // 
            // txtjob3
            // 
            this.txtjob3.Location = new System.Drawing.Point(553, 101);
            this.txtjob3.Name = "txtjob3";
            this.txtjob3.Size = new System.Drawing.Size(501, 61);
            this.txtjob3.TabIndex = 38;
            this.txtjob3.Text = "";
            // 
            // txttime3
            // 
            this.txttime3.Location = new System.Drawing.Point(330, 101);
            this.txttime3.Name = "txttime3";
            this.txttime3.Size = new System.Drawing.Size(217, 61);
            this.txttime3.TabIndex = 37;
            this.txttime3.Text = "";
            // 
            // txtday3
            // 
            this.txtday3.Location = new System.Drawing.Point(247, 101);
            this.txtday3.Name = "txtday3";
            this.txtday3.Size = new System.Drawing.Size(77, 61);
            this.txtday3.TabIndex = 36;
            this.txtday3.Text = "";
            // 
            // txtjob2
            // 
            this.txtjob2.Location = new System.Drawing.Point(553, 28);
            this.txtjob2.Name = "txtjob2";
            this.txtjob2.Size = new System.Drawing.Size(501, 61);
            this.txtjob2.TabIndex = 35;
            this.txtjob2.Text = "";
            // 
            // txttime2
            // 
            this.txttime2.Location = new System.Drawing.Point(330, 28);
            this.txttime2.Name = "txttime2";
            this.txttime2.Size = new System.Drawing.Size(217, 61);
            this.txttime2.TabIndex = 34;
            this.txttime2.Text = "";
            // 
            // txtday2
            // 
            this.txtday2.Location = new System.Drawing.Point(247, 28);
            this.txtday2.Name = "txtday2";
            this.txtday2.Size = new System.Drawing.Size(77, 61);
            this.txtday2.TabIndex = 33;
            this.txtday2.Text = "";
            // 
            // dtgv7
            // 
            this.dtgv7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv7.Location = new System.Drawing.Point(40, 385);
            this.dtgv7.Name = "dtgv7";
            this.dtgv7.Size = new System.Drawing.Size(118, 74);
            this.dtgv7.TabIndex = 32;
            // 
            // dtgv6
            // 
            this.dtgv6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv6.Location = new System.Drawing.Point(40, 314);
            this.dtgv6.Name = "dtgv6";
            this.dtgv6.Size = new System.Drawing.Size(118, 65);
            this.dtgv6.TabIndex = 31;
            // 
            // dtgv5
            // 
            this.dtgv5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv5.Location = new System.Drawing.Point(40, 248);
            this.dtgv5.Name = "dtgv5";
            this.dtgv5.Size = new System.Drawing.Size(118, 60);
            this.dtgv5.TabIndex = 30;
            // 
            // dtgv4
            // 
            this.dtgv4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv4.Location = new System.Drawing.Point(40, 175);
            this.dtgv4.Name = "dtgv4";
            this.dtgv4.Size = new System.Drawing.Size(118, 66);
            this.dtgv4.TabIndex = 29;
            // 
            // dtgv3
            // 
            this.dtgv3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv3.Location = new System.Drawing.Point(40, 100);
            this.dtgv3.Name = "dtgv3";
            this.dtgv3.Size = new System.Drawing.Size(118, 66);
            this.dtgv3.TabIndex = 28;
            // 
            // dtgv2
            // 
            this.dtgv2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column3});
            this.dtgv2.Location = new System.Drawing.Point(40, 22);
            this.dtgv2.Name = "dtgv2";
            this.dtgv2.Size = new System.Drawing.Size(118, 72);
            this.dtgv2.TabIndex = 27;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "thoigian";
            this.Column3.HeaderText = "Giờ";
            this.Column3.Name = "Column3";
            // 
            // dtgvcn
            // 
            this.dtgvcn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvcn.Location = new System.Drawing.Point(40, 465);
            this.dtgvcn.Name = "dtgvcn";
            this.dtgvcn.Size = new System.Drawing.Size(118, 70);
            this.dtgvcn.TabIndex = 26;
            // 
            // btnsua
            // 
            this.btnsua.Location = new System.Drawing.Point(1078, 112);
            this.btnsua.Name = "btnsua";
            this.btnsua.Size = new System.Drawing.Size(75, 50);
            this.btnsua.TabIndex = 12;
            this.btnsua.Text = "Cập nhật";
            this.btnsua.UseVisualStyleBackColor = true;
            // 
            // btnxoa
            // 
            this.btnxoa.Location = new System.Drawing.Point(1078, 187);
            this.btnxoa.Name = "btnxoa";
            this.btnxoa.Size = new System.Drawing.Size(75, 50);
            this.btnxoa.TabIndex = 11;
            this.btnxoa.Text = "Xóa";
            this.btnxoa.UseVisualStyleBackColor = true;
            this.btnxoa.Click += new System.EventHandler(this.btnxoa_Click);
            // 
            // btnthem
            // 
            this.btnthem.Location = new System.Drawing.Point(1078, 44);
            this.btnthem.Name = "btnthem";
            this.btnthem.Size = new System.Drawing.Size(75, 50);
            this.btnthem.TabIndex = 10;
            this.btnthem.Text = "Thêm";
            this.btnthem.UseVisualStyleBackColor = true;
            this.btnthem.Click += new System.EventHandler(this.btnthem_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(458, 26);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(278, 42);
            this.label8.TabIndex = 1;
            this.label8.Text = "Thời khóa biểu";
            // 
            // txtid2
            // 
            this.txtid2.Location = new System.Drawing.Point(180, 28);
            this.txtid2.Name = "txtid2";
            this.txtid2.Size = new System.Drawing.Size(45, 61);
            this.txtid2.TabIndex = 57;
            this.txtid2.Text = "";
            // 
            // txtid3
            // 
            this.txtid3.Location = new System.Drawing.Point(180, 101);
            this.txtid3.Name = "txtid3";
            this.txtid3.Size = new System.Drawing.Size(45, 61);
            this.txtid3.TabIndex = 58;
            this.txtid3.Text = "";
            // 
            // txtid4
            // 
            this.txtid4.Location = new System.Drawing.Point(180, 179);
            this.txtid4.Name = "txtid4";
            this.txtid4.Size = new System.Drawing.Size(45, 58);
            this.txtid4.TabIndex = 59;
            this.txtid4.Text = "";
            // 
            // txtid5
            // 
            this.txtid5.Location = new System.Drawing.Point(180, 248);
            this.txtid5.Name = "txtid5";
            this.txtid5.Size = new System.Drawing.Size(45, 60);
            this.txtid5.TabIndex = 60;
            this.txtid5.Text = "";
            // 
            // txtid6
            // 
            this.txtid6.Location = new System.Drawing.Point(180, 321);
            this.txtid6.Name = "txtid6";
            this.txtid6.Size = new System.Drawing.Size(45, 54);
            this.txtid6.TabIndex = 61;
            this.txtid6.Text = "";
            this.txtid6.TextChanged += new System.EventHandler(this.richTextBox5_TextChanged);
            // 
            // txtid7
            // 
            this.txtid7.Location = new System.Drawing.Point(180, 385);
            this.txtid7.Name = "txtid7";
            this.txtid7.Size = new System.Drawing.Size(45, 61);
            this.txtid7.TabIndex = 62;
            this.txtid7.Text = "";
            // 
            // txtidcn
            // 
            this.txtidcn.Location = new System.Drawing.Point(180, 480);
            this.txtidcn.Name = "txtidcn";
            this.txtidcn.Size = new System.Drawing.Size(45, 51);
            this.txtidcn.TabIndex = 63;
            this.txtidcn.Text = "";
            // 
            // fLich
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1350, 636);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.panel1);
            this.Name = "fLich";
            this.Text = "fLich";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvcn)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button btnsua;
        private System.Windows.Forms.Button btnxoa;
        private System.Windows.Forms.Button btnthem;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView dtgvcn;
        private System.Windows.Forms.DataGridView dtgv7;
        private System.Windows.Forms.DataGridView dtgv6;
        private System.Windows.Forms.DataGridView dtgv5;
        private System.Windows.Forms.DataGridView dtgv4;
        private System.Windows.Forms.DataGridView dtgv3;
        private System.Windows.Forms.DataGridView dtgv2;
        private System.Windows.Forms.RichTextBox txtjobcn;
        private System.Windows.Forms.RichTextBox txttimecn;
        private System.Windows.Forms.RichTextBox txtdaycn;
        private System.Windows.Forms.RichTextBox txtjob7;
        private System.Windows.Forms.RichTextBox txttime7;
        private System.Windows.Forms.RichTextBox txtday7;
        private System.Windows.Forms.RichTextBox txtjob6;
        private System.Windows.Forms.RichTextBox txttime6;
        private System.Windows.Forms.RichTextBox txtday6;
        private System.Windows.Forms.RichTextBox txtjob5;
        private System.Windows.Forms.RichTextBox txttime5;
        private System.Windows.Forms.RichTextBox txtday5;
        private System.Windows.Forms.RichTextBox txtjob4;
        private System.Windows.Forms.RichTextBox txttime4;
        private System.Windows.Forms.RichTextBox txtday4;
        private System.Windows.Forms.RichTextBox txtjob3;
        private System.Windows.Forms.RichTextBox txttime3;
        private System.Windows.Forms.RichTextBox txtday3;
        private System.Windows.Forms.RichTextBox txtjob2;
        private System.Windows.Forms.RichTextBox txttime2;
        private System.Windows.Forms.RichTextBox txtday2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox txtid7;
        private System.Windows.Forms.RichTextBox txtid6;
        private System.Windows.Forms.RichTextBox txtid5;
        private System.Windows.Forms.RichTextBox txtid4;
        private System.Windows.Forms.RichTextBox txtid3;
        private System.Windows.Forms.RichTextBox txtid2;
        private System.Windows.Forms.RichTextBox txtidcn;
    }
}